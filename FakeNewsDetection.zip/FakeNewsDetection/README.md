# Fake News Detection

This project is a simple implementation of a fake news detection system using Python and machine learning.

## Features
- Uses Logistic Regression to classify news as FAKE or REAL
- Applies TfidfVectorizer for text feature extraction
- Includes a sample prediction function

## How to Run
1. Install the required libraries using `pip install -r requirements.txt`
2. Place the `fake_or_real_news.csv` dataset in the project folder
3. Run the script: `python main.py`

## Dataset
Download the dataset from: https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset

## Author
Your Name
